#!/bin/sh
set -e
java -jar /scripts/marcelo-vw-test.jar