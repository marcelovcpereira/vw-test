#!/bin/bash
java -jar /usr/local/bin/marcelo-vw-test.jar